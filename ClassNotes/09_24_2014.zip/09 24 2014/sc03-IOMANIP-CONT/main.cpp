#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    /*
    string car1 = "BMW Z4";
    string car2 = "Aston Martin Vantage";
    string car3 = "Toyota Corolla";

    double mpgCar1 =  29.5;
    double mpgCar2 = 11.2;
    double mpgCar3 = 39.9;

    cout << left;
    cout << setw(10) << car1
         << setw(22) << car2
         << setw(18) << car3 << endl;
    cout << setw(10) << mpgCar1
         << setw(22) << mpgCar2
         << setw(18) << mpgCar3 << endl;

    */

    double x = 3.14159265;
    double num;
    cout << "enter a number: ";
    cin >> num;
    cout << showpoint;
    cout << "YOu entered : " << num << endl;



    return 0;
}
