#include <iostream>

using namespace std;

int main()
{
    // for loop with section omitted
    int i=0;
    for (; i<10; i=i+2)
    {
       //cout << "I am an infinite loop" << endl;
       cout << "i : " << i << endl;

    }

        return 0;
}
