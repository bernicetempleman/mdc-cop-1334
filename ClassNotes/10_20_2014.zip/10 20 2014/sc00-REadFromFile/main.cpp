#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>

using namespace std;

int main()
{
    ifstream inputF;      // this will be associated with the input data file
    string   lineOfText;  // from file
    // open the file for reading
    inputF.open("DrinkInventory.txt");
    if (!inputF)
    {
        cout << "Trouble locating the file. Exiting the program...." << endl;
        exit(EXIT_FAILURE);
    }

    // process the file
    while (!inputF.eof())
    {
       getline(inputF, lineOfText,',');
       cout << lineOfText + '\t';
    }

    // close the file
    inputF.close();

    return 0;
}
