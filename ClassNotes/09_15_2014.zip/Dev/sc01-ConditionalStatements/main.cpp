#include <iostream>

using namespace std;

int main()
{
    int myNumber;
    cout << "Enter a number: ";
    cin >> myNumber;
    // the expression will evaluate to TRUE or FALSE
    if (myNumber == 100)
        cout << "My number is 100" << endl;

    cout << "Have a nice day" << endl;
    return 0;
}
