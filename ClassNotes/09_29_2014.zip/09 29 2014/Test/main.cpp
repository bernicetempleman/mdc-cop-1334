#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    cout << setw (9) << fixed << setprecision (2) << 34.789 << endl;
    return 0;
}
