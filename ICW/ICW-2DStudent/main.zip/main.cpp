/* Programmer: Bernice Templeman
 * ICW: Student Grades
 *
 * Description:
 * Suppose you have 3 students in your class.
 * Each student took 4 exams which is depicted below:
 *
 * Write a program that will determine
 *    average for each student,
 *    and a highest and
 *    lowest grade for each exam.
 * Note: The students are “rows”
 *    and the exams are“columns”
 * add a parallel array that will contain student names,
 *    Joe, Jake, and Jill and relate it to the 2D array you just created.
 * Write displayStudentGrades function where you will display
 *    student name
 *    and all of their grades
 * add a parallel array that will contain Exam names, i.e.
 *    “Exam1”,“Exam2”,“Exam3”, and“Exam4”.
 * Write displayExamStats function that will display the
 *   exam name,
 *   and the highest and
 *   the lowest score
 *   for each exam.
 */

#include <iostream>
#include <iomanip>

using namespace std;

//constants
const int NUM_EXAMS = 4;
const int NUM_STUDENTS = 3;

// function prototypes
double studentAverage(int, int [][NUM_EXAMS]);
int getMaxScore(int , int [][NUM_EXAMS]);
int getMinScore(int , int [][NUM_EXAMS]);
void displayStudentGrades(int [][NUM_EXAMS],string[]);
void displayExamStats(int [][NUM_EXAMS], string[]);

int main()
{
    //studebt Grade array ( studebts are rows, grades are columns
    int studentGrades[][NUM_EXAMS] = {

                            {55, 80, 77, 95},

                            {80, 85, 90, 92},

                            {100, 78, 89, 95}

                         };
    //parallel array that will contain student names
    string names[] = {"Joe","Jake","Jill"};

    //parallel array that will contain Exam names
    string exams[] = {"Exam1", "Exam2", "Exam3", "Exam4"};

    //get average of each student
    for (int curStud=0; curStud<NUM_STUDENTS; curStud++)
    {
        cout << "Student "  << curStud+1
             << " average is: "
             << studentAverage(curStud,studentGrades)
             << endl;
    }

    cout << endl;

    //get highest score for each exam
    for (int curExam = 0; curExam<NUM_EXAMS; curExam++)
    {
        cout << "Exam "  << curExam+1
             << " highest score is: "
             << getMaxScore(curExam,studentGrades)
             << endl;
    }

    cout << endl;

    //get lowest score for each exam
    for (int curExam = 0; curExam<NUM_EXAMS; curExam++)
    {
        cout << "Exam "  << curExam+1
             << " lowest score is: "
             << getMinScore(curExam,studentGrades)
             << endl;
    }

    //Display student names & grade
    displayStudentGrades(studentGrades, names);

    //Display Exam Name & highest & lowest Grade//
    displayExamStats(studentGrades, exams);

    //Displays 2-D array
    //display2DArray(studentGrades);

    return 0;

}

//functions

// function that will calculate student average
double studentAverage(int currentStudent,int myStudents[][NUM_EXAMS] )
{
    double sum = 0;
    double avg;
    for (int i=0; i<NUM_EXAMS; i++)
    {
        sum = sum + myStudents[currentStudent][i];
    }
    avg = sum / NUM_EXAMS;
    return avg;
}

//function gets MAX score
int getMaxScore(int currExam, int myStudents[][NUM_EXAMS])
{
    int maxScore = myStudents[0][currExam];

    for (int i=1; i<NUM_STUDENTS; i++)
    {
        if (myStudents[i][currExam] > maxScore)
            maxScore = myStudents[i][currExam];
    }

    return maxScore;
}

//function gets min score
int getMinScore(int currExam, int myStudents[][NUM_EXAMS])
{
    int minScore = myStudents[0][currExam];

    for (int i=1; i<NUM_STUDENTS; i++)
    {
        if (myStudents[i][currExam] < minScore)
            minScore = myStudents[i][currExam];
    }

    return minScore;
}

//Display student names & grades
void displayStudentGrades(int anArray[][NUM_EXAMS], string names[])
{
    int fieldWidth = 10;
    int fieldGradeWidth = 3;

    cout << endl;


    for (int i=0; i<NUM_STUDENTS; i++)
    {
        cout
        << left
        << setw(fieldWidth)
        << names[i]
        << "Grades: ";
        for (int j=0; j<NUM_EXAMS; j++)
        {
            cout << setw(fieldGradeWidth) << anArray[i][j] << " ";
        }
        cout << endl;
    }
}

//function Display Exam Stats
// calls functions getMinScore & getMaxScore
void displayExamStats(int anArray[][NUM_EXAMS], string exams[])
{
    int examMin;
    int examMax;
    int fieldWidth = 15;

    cout << endl;

    for (int curExam = 0; curExam<NUM_EXAMS; curExam++)
    {
        examMin = getMinScore(curExam,anArray);
        examMax = getMaxScore(curExam,anArray);

        cout << exams[curExam]

             << ":  "
             << setw(fieldWidth)
            << "Min Score "
             << examMin
             << setw(fieldWidth)
             << "     Max Score "
             << examMax
             <<endl;
    }

    cout << endl;
}


